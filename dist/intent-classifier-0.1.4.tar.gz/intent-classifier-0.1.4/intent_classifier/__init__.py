__version__ = '0.1.4'
__all__ = ['intent_classifier']
from .intent_classifier import IntentClassifier
